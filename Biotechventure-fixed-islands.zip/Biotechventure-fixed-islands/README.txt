Biotechventure repaired website

Open index.html in a modern browser. Click Play Biotechventure, then START ADVENTURE. The eight islands are bundled locally inside the page. Press Esc to leave fullscreen.
